<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Manage Blog Entries</title>
    <link href="../styles/admin.css" rel="stylesheet" type="text/css">
</head>

<body>
<h1>Manage Blog Entries</h1>
<p><a href="blog_insert.php">Insert new entry</a></p>
<table>
    <tr>
        <th>Created</th>
        <th>Title</th>
        <th>&nbsp;</th>
        <th>&nbsp;</th>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td><a href="blog_update.php">EDIT</a></td>
        <td><a href="blog_delete.php">DELETE</a></td>
    </tr>
</table>
</body>
</html>